import Route from "@ioc:Adonis/Core/Route";

Route.get("/", async ({ view }) => {
  return view.render("welcome");
});

Route.group(() => {
  // product routes
  Route.get("/products", "ProductsController.getProducts");
  Route.get("/products/:id", "ProductsController.getProductById");
  Route.post("/products", "ProductsController.addProduct");
  Route.patch("/products/:id", "ProductsController.updateProduct");
  Route.delete("/products/:id", "ProductsController.deleteProduct");

  // customer routes
  Route.get("/customers", "CustomersController.getCustomer");
  Route.get("/customers/:id", "CustomersController.getCustomerbyId");
  Route.post("/customers", "CustomersController.addCustomer");
  Route.put("/customers/:id", "CustomersController.updateCustomer");
  Route.delete("/customers/:id", "CustomersController.deleteCustomer");

  // Order Route
  Route.get("/orders", "OrdersController.getOrders");
  Route.get("/orders/:id", "OrdersController.getOrderbyId");
  Route.post("/orders", "OrdersController.addOrder");
  Route.patch("/orders/:id", "OrdersController.updateOrder");
  Route.delete("/orders/:id", "OrdersController.deleteOrder");

  //orderItems Route
  Route.get('/items', 'OrderItemsController.getAllOrders');
  Route.post('/item/add', 'OrderItemsController.addItem');


}).prefix("api");
