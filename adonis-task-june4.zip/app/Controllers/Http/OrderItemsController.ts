import { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import OrderItem from 'App/Models/OrderItem'

export default class OrderItemsController {
    
    // get all order items
    public async getAllOrders({response} : HttpContextContract) {
        const result = await OrderItem.all();
        response.json({result});
    }

    // add order item
    public async addItem({request, response} : HttpContextContract) {
        const item = new OrderItem();
        item.order_no = request.input('order_no');
        item.product_id = request.input('product_id');
        let quantity = item.quantity = request.input('quantity');
        let ppi =  item.price_per_item = request.input('price_per_item');
        item.amount = (quantity * ppi)
        await item.save();
        response.status(201).json({item});
    }


}
